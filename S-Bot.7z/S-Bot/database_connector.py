import mysql.connector

database = mysql.connector.connect(user='root', password='root',
                                   host='localhost',
                                   database='newschema2')